package net.viralpatel.android.mediascanner;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class MediaScannerDemoActivity extends Activity {
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		Button buttonMediaScanner = (Button) findViewById(R.id.buttonMediaScanner);
		buttonMediaScanner.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View view) {
				
				//Broadcast the Media Scanner Intent to trigger it
				sendBroadcast(new Intent(Intent.ACTION_MEDIA_MOUNTED, Uri
						.parse("file://"
								+ Environment.getExternalStorageDirectory())));

				//Just a message
				Toast toast = Toast.makeText(getApplicationContext(),
						"Media Scanner Triggered...", Toast.LENGTH_SHORT);
				toast.show();
			}
		});

	}
}